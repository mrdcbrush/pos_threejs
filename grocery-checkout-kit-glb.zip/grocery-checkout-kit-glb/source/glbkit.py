"""Minimal GLB (binary glTF 2.0) authoring kit: primitives, nodes, materials, animations."""
import json, math, struct
import numpy as np

# ------------------------------------------------------------------ colour
def srgb_to_linear(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

def hex_rgb(h):
    return ((h >> 16) & 255, (h >> 8) & 255, h & 255)

def hex_lin(h):
    return [round(srgb_to_linear(v), 5) for v in hex_rgb(h)]

# ------------------------------------------------------------------ geometry
def _fix_winding(pos, nrm, idx):
    tri = idx.reshape(-1, 3)
    a, b, c = pos[tri[:, 0]], pos[tri[:, 1]], pos[tri[:, 2]]
    fn = np.cross(b - a, c - a)
    vn = nrm[tri[:, 0]] + nrm[tri[:, 1]] + nrm[tri[:, 2]]
    flip = np.einsum('ij,ij->i', fn, vn) < 0
    tri[flip] = tri[flip][:, [0, 2, 1]]
    return tri.reshape(-1)

def _finish(pos, nrm, idx, offset=(0, 0, 0)):
    pos = np.asarray(pos, np.float32) + np.asarray(offset, np.float32)
    nrm = np.asarray(nrm, np.float32)
    nrm /= np.maximum(np.linalg.norm(nrm, axis=1, keepdims=True), 1e-9)
    idx = _fix_winding(pos, nrm, np.asarray(idx, np.int64))
    return pos, nrm, idx

def g_box(w, h, d, offset=(0, 0, 0)):
    hx, hy, hz = w / 2, h / 2, d / 2
    pos, nrm, idx = [], [], []
    for axis in range(3):
        for s in (-1, 1):
            n = [0, 0, 0]; n[axis] = s
            u, v = [(1, 2), (0, 2), (0, 1)][axis]
            half = [hx, hy, hz]
            base = len(pos)
            for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                p = [0, 0, 0]
                p[axis] = s * half[axis]; p[u] = su * half[u]; p[v] = sv * half[v]
                pos.append(p); nrm.append(n)
            idx += [base, base + 1, base + 2, base, base + 2, base + 3]
    return _finish(pos, nrm, idx, offset)

def g_rbox(w, h, d, r=0.02, S=2, offset=(0, 0, 0)):
    half = np.array([w, h, d]) / 2
    r = max(0.0005, min(r, 0.45 * min(w, h, d)))
    inner = half - r
    a = np.linspace(0, math.pi / 2, S + 1)
    def coords(ax):
        return np.concatenate([-inner[ax] - r * np.cos(a), inner[ax] + r * np.sin(a)])
    pos, nrm, idx = [], [], []
    for k in range(3):
        i, j = [(1, 2), (0, 2), (0, 1)][k]
        ci, cj = coords(i), coords(j)
        for s in (-1, 1):
            base = len(pos)
            for vi in ci:
                for vj in cj:
                    p = np.zeros(3); p[k] = s * half[k]; p[i] = vi; p[j] = vj
                    q = np.clip(p, -inner, inner)
                    dv = p - q
                    n = dv / np.linalg.norm(dv)
                    pos.append(q + r * n); nrm.append(n)
            m = len(cj)
            for x in range(len(ci) - 1):
                for y in range(m - 1):
                    p0 = base + x * m + y
                    idx += [p0, p0 + m, p0 + m + 1, p0, p0 + m + 1, p0 + 1]
    return _finish(pos, nrm, idx, offset)

def g_cyl(rt, rb, h, seg=24, open_ended=False, flat=False, theta0=0.0, offset=(0, 0, 0)):
    pos, nrm, idx = [], [], []
    hy = h / 2
    th = [theta0 + 2 * math.pi * i / seg for i in range(seg + 1)]
    slope = rb - rt
    if flat:
        for i in range(seg):
            t0, t1 = th[i], th[i + 1]
            quad = [(rt, hy, t0), (rt, hy, t1), (rb, -hy, t1), (rb, -hy, t0)]
            tm = (t0 + t1) / 2
            n = [math.sin(tm) * h, slope, math.cos(tm) * h]
            base = len(pos)
            for rr, yy, tt in quad:
                pos.append([rr * math.sin(tt), yy, rr * math.cos(tt)]); nrm.append(n)
            idx += [base, base + 1, base + 2, base, base + 2, base + 3]
    else:
        base = len(pos)
        for t in th:
            n = [math.sin(t) * h, slope, math.cos(t) * h]
            pos.append([rt * math.sin(t), hy, rt * math.cos(t)]); nrm.append(n)
            pos.append([rb * math.sin(t), -hy, rb * math.cos(t)]); nrm.append(n)
        for i in range(seg):
            a0 = base + 2 * i
            idx += [a0, a0 + 2, a0 + 3, a0, a0 + 3, a0 + 1]
    if not open_ended:
        for y, rr, ny in ((hy, rt, 1), (-hy, rb, -1)):
            if rr <= 0:
                continue
            c = len(pos)
            pos.append([0, y, 0]); nrm.append([0, ny, 0])
            for t in th:
                pos.append([rr * math.sin(t), y, rr * math.cos(t)]); nrm.append([0, ny, 0])
            for i in range(seg):
                idx += [c, c + 1 + i, c + 2 + i]
    return _finish(pos, nrm, idx, offset)

def g_prism(points, depth, offset=(0, 0, 0)):
    """Convex polygon in XY extruded along Z, centred on its bounding box."""
    pts = np.array(points, float)
    pts -= (pts.min(0) + pts.max(0)) / 2
    hz = depth / 2
    pos, nrm, idx = [], [], []
    n = len(pts)
    for z, nz in ((hz, 1), (-hz, -1)):
        base = len(pos)
        for p in pts:
            pos.append([p[0], p[1], z]); nrm.append([0, 0, nz])
        for i in range(1, n - 1):
            idx += [base, base + i, base + i + 1]
    centre = pts.mean(0)
    for i in range(n):
        p0, p1 = pts[i], pts[(i + 1) % n]
        e = p1 - p0
        out = np.array([e[1], -e[0]])
        if np.dot(out, (p0 + p1) / 2 - centre) < 0:
            out = -out
        nn = [out[0], out[1], 0]
        base = len(pos)
        for p, z in ((p0, hz), (p1, hz), (p1, -hz), (p0, -hz)):
            pos.append([p[0], p[1], z]); nrm.append(nn)
        idx += [base, base + 1, base + 2, base, base + 2, base + 3]
    return _finish(pos, nrm, idx, offset)

GEN = {'box': g_box, 'rbox': g_rbox, 'cyl': g_cyl, 'prism': g_prism}

# ------------------------------------------------------------------ scene graph
def euler_xyz_to_quat(x, y, z):
    c1, c2, c3 = math.cos(x / 2), math.cos(y / 2), math.cos(z / 2)
    s1, s2, s3 = math.sin(x / 2), math.sin(y / 2), math.sin(z / 2)
    return [s1 * c2 * c3 + c1 * s2 * s3, c1 * s2 * c3 - s1 * c2 * s3,
            c1 * c2 * s3 + s1 * s2 * c3, c1 * c2 * c3 - s1 * s2 * s3]

def quat_to_mat(q):
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])

class Node:
    def __init__(self, name, parent=None, t=(0, 0, 0), r=(0, 0, 0), s=(1, 1, 1), mesh=None, label=None):
        self.name, self.t, self.r, self.s, self.mesh = name, list(t), list(r), list(s), mesh
        self.children, self.extras = [], {}
        if label:
            self.extras['label'] = label
        if parent is not None:
            parent.children.append(self)

    def quat(self):
        return euler_xyz_to_quat(*self.r)

    def matrix(self):
        m = np.eye(4)
        m[:3, :3] = quat_to_mat(self.quat()) * np.array(self.s)
        m[:3, 3] = self.t
        return m

    def walk(self, fn, parent_m=np.eye(4)):
        m = parent_m @ self.matrix()
        fn(self, m)
        for c in self.children:
            c.walk(fn, m)

    def find(self, name):
        if self.name == name:
            return self
        for c in self.children:
            f = c.find(name)
            if f:
                return f
        return None

class Material:
    def __init__(self, name, color, rough=0.6, metal=0.0, emissive=None, intensity=1.0, alpha=1.0, double=False):
        self.name, self.color, self.rough, self.metal = name, color, rough, metal
        self.emissive, self.intensity, self.alpha, self.double = emissive, intensity, alpha, double

    def to_gltf(self):
        base = hex_lin(self.color) + [self.alpha]
        m = {'name': self.name,
             'pbrMetallicRoughness': {'baseColorFactor': base, 'metallicFactor': self.metal, 'roughnessFactor': self.rough}}
        ext = False
        if self.emissive is not None:
            f = hex_lin(self.emissive)
            if self.intensity <= 1:
                m['emissiveFactor'] = [round(c * self.intensity, 5) for c in f]
            else:
                m['emissiveFactor'] = f
                m['extensions'] = {'KHR_materials_emissive_strength': {'emissiveStrength': self.intensity}}
                ext = True
        if self.alpha < 1:
            m['alphaMode'] = 'BLEND'
        if self.double:
            m['doubleSided'] = True
        return m, ext

class Mesh:
    """A geometry spec (generator name + args) bound to a material name."""
    def __init__(self, gen, args, kwargs, material):
        self.gen, self.args, self.kwargs, self.material = gen, tuple(args), tuple(sorted(kwargs.items())), material

    @property
    def geo_key(self):
        return (self.gen, self.args, self.kwargs)

class Animation:
    def __init__(self, name):
        self.name, self.channels = name, []  # (node, path, times, values)

    def add(self, node, path, times, values):
        self.channels.append((node, path, np.asarray(times, np.float32), np.asarray(values, np.float32)))

# ------------------------------------------------------------------ writer
def write_glb(path, roots, materials, animations=(), generator='Grocery checkout kit builder'):
    nodes, node_index = [], {}
    def collect(n):
        node_index[id(n)] = len(nodes)
        nodes.append(n)
        for c in n.children:
            collect(c)
    for r in roots:
        collect(r)

    mat_names = []
    for n in nodes:
        if n.mesh and n.mesh.material not in mat_names:
            mat_names.append(n.mesh.material)

    bin_data = bytearray()
    buffer_views, accessors = [], []

    def add_view(data, target=None):
        while len(bin_data) % 4:
            bin_data.append(0)
        off = len(bin_data)
        bin_data.extend(data)
        bv = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
        if target:
            bv['target'] = target
        buffer_views.append(bv)
        return len(buffer_views) - 1

    def add_accessor(arr, ctype, typ, target=None, minmax=False):
        view = add_view(arr.tobytes(), target)
        acc = {'bufferView': view, 'componentType': ctype, 'count': int(arr.shape[0]), 'type': typ}
        if minmax:
            a2 = arr.reshape(arr.shape[0], -1)
            acc['min'] = [float(v) for v in a2.min(0)]
            acc['max'] = [float(v) for v in a2.max(0)]
        accessors.append(acc)
        return len(accessors) - 1

    geo_cache, mesh_cache, meshes = {}, {}, []
    tri_count = 0
    for n in nodes:
        if not n.mesh:
            continue
        gk = n.mesh.geo_key
        if gk not in geo_cache:
            pos, nrm, idx = GEN[n.mesh.gen](*n.mesh.args, **dict(n.mesh.kwargs))
            pa = add_accessor(pos.astype(np.float32), 5126, 'VEC3', 34962, True)
            na = add_accessor(nrm.astype(np.float32), 5126, 'VEC3', 34962)
            if len(pos) < 65535:
                ia = add_accessor(idx.astype(np.uint16), 5123, 'SCALAR', 34963, True)
            else:
                ia = add_accessor(idx.astype(np.uint32), 5125, 'SCALAR', 34963, True)
            geo_cache[gk] = (pa, na, ia, len(idx) // 3)
        mk = (gk, n.mesh.material)
        if mk not in mesh_cache:
            pa, na, ia, tris = geo_cache[gk]
            meshes.append({'name': f'{n.name}_mesh', 'primitives': [{
                'attributes': {'POSITION': pa, 'NORMAL': na}, 'indices': ia,
                'material': mat_names.index(n.mesh.material), 'mode': 4}]})
            mesh_cache[mk] = len(meshes) - 1
        tri_count += geo_cache[gk][3]

    gltf_nodes = []
    for n in nodes:
        g = {'name': n.name}
        if any(abs(v) > 1e-12 for v in n.t):
            g['translation'] = [round(float(v), 6) for v in n.t]
        if any(abs(v) > 1e-12 for v in n.r):
            g['rotation'] = [round(float(v), 7) for v in n.quat()]
        if any(abs(v - 1) > 1e-12 for v in n.s):
            g['scale'] = [float(v) for v in n.s]
        if n.mesh:
            g['mesh'] = mesh_cache[(n.mesh.geo_key, n.mesh.material)]
        if n.children:
            g['children'] = [node_index[id(c)] for c in n.children]
        if n.extras:
            g['extras'] = n.extras
        gltf_nodes.append(g)

    gl_anims = []
    for anim in animations:
        samplers, channels = [], []
        for node, tpath, times, values in anim.channels:
            if id(node) not in node_index:
                continue
            ia = add_accessor(times.reshape(-1), 5126, 'SCALAR', None, True)
            typ = "VEC4" if tpath == "rotation" else "VEC3"
            oa = add_accessor(values.reshape(len(times), -1), 5126, typ)
            samplers.append({'input': ia, 'output': oa, 'interpolation': 'LINEAR'})
            channels.append({'sampler': len(samplers) - 1, 'target': {'node': node_index[id(node)], 'path': tpath}})
        if channels:
            gl_anims.append({'name': anim.name, 'samplers': samplers, 'channels': channels})

    mats_json, ext_used = [], False
    for name in mat_names:
        mj, e = materials[name].to_gltf()
        mats_json.append(mj)
        ext_used |= e

    while len(bin_data) % 4:
        bin_data.append(0)
    doc = {
        'asset': {'version': '2.0', 'generator': generator},
        'scene': 0,
        'scenes': [{'name': roots[0].name, 'nodes': [node_index[id(r)] for r in roots]}],
        'nodes': gltf_nodes, 'meshes': meshes, 'materials': mats_json,
        'accessors': accessors, 'bufferViews': buffer_views,
        'buffers': [{'byteLength': len(bin_data)}],
    }
    if gl_anims:
        doc['animations'] = gl_anims
    if ext_used:
        doc['extensionsUsed'] = ['KHR_materials_emissive_strength']
    js = json.dumps(doc, separators=(',', ':')).encode('utf-8')
    js += b' ' * ((4 - len(js) % 4) % 4)
    total = 12 + 8 + len(js) + 8 + len(bin_data)
    with open(path, 'wb') as f:
        f.write(struct.pack('<III', 0x46546C67, 2, total))
        f.write(struct.pack('<II', len(js), 0x4E4F534A)); f.write(js)
        f.write(struct.pack('<II', len(bin_data), 0x004E4942)); f.write(bin_data)
    return {'bytes': total, 'nodes': len(nodes), 'meshes': len(meshes), 'materials': len(mat_names),
            'triangles': tri_count, 'animations': [a['name'] for a in gl_anims]}
