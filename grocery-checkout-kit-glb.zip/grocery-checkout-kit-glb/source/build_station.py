import copy, json, math, os, sys
import numpy as np
from glbkit import Node, Material, Mesh, Animation, write_glb, euler_xyz_to_quat

OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
LANE_NUMBER = '4'
TAU = 2 * math.pi

# ------------------------------------------------------------------ shared kit materials
MAT = {m.name: m for m in [
    Material('Kit_Cabinet', 0xe8e3d9, 0.75),
    Material('Kit_Accent', 0x2f7d6d, 0.55),
    Material('Kit_Kick', 0x3b4048, 0.8),
    Material('Kit_Countertop', 0xb7bcc2, 0.42, 0.3),
    Material('Kit_Steel', 0xcfd4d9, 0.32, 0.35),
    Material('Kit_Rubber', 0x24272c, 0.92),
    Material('Kit_Ridge', 0x3a3e45, 0.85),
    Material('Kit_DarkPlastic', 0x2a2e35, 0.5),
    Material('Kit_MidPlastic', 0x4b525c, 0.55),
    Material('Kit_LightPlastic', 0xc9cdd2, 0.6),
    Material('Kit_KeyRed', 0xd9483b, 0.5),
    Material('Kit_KeyYellow', 0xe8b93a, 0.5),
    Material('Kit_KeyGreen', 0x3aa564, 0.5),
    Material('Kit_Bag', 0xf3f3ee, 0.85, alpha=0.9, double=True),
    Material('Kit_Paper', 0xfbfbf8, 0.9, double=True),
    Material('Kit_FloorMat', 0x31353c, 0.95),
    # Glowing parts: one material each so they can be animated independently.
    Material('Glow_ScannerGlass', 0x173640, 0.1, 0.2, emissive=0xff2b2b, intensity=0.1),
    Material('Glow_ScannerLED', 0x0b2a14, 0.3, emissive=0x3ddc84, intensity=0.6),
    Material('Glow_BeltEye', 0x2a0b0b, 0.3, emissive=0xff2b2b, intensity=0.8),
    Material('Glow_POSScreen', 0x0c141c, 0.25, emissive=0x2f8fe8, intensity=0.55),
    Material('Glow_CustomerScreen', 0x0c141c, 0.25, emissive=0x2f8fe8, intensity=0.55),
    Material('Glow_PinPadScreen', 0x0c141c, 0.25, emissive=0x2f8fe8, intensity=0.5),
    Material('Glow_ScreenUI', 0xffffff, 0.3, emissive=0xdcebff, intensity=0.4),
    Material('Glow_ScreenTotal', 0xffffff, 0.3, emissive=0xf0b43c, intensity=0.5),
    Material('Glow_PrinterLED', 0x0b2a14, 0.3, emissive=0x3ddc84, intensity=0.8),
    Material('Glow_LaneLamp', 0x0d2414, 0.3, emissive=0x3ddc84, intensity=1.4),
    Material('Glow_LaneNumber', 0xffffff, 0.4, emissive=0xffffff, intensity=0.6),
]}

def box(w, h, d, **k): return ('box', (w, h, d), k)
def rbox(w, h, d, r=0.02, **k): return ('rbox', (w, h, d, r), k)
def cyl(rt, rb, h, seg=24, **k): return ('cyl', (rt, rb, h, seg), k)

def P(geo, mat, name, parent, t=(0, 0, 0), r=(0, 0, 0), s=(1, 1, 1), label=None):
    gen, args, kw = geo
    return Node(name, parent, t, r, s, Mesh(gen, args, kw, mat), label)

def G(name, parent, t=(0, 0, 0), r=(0, 0, 0), label=None):
    return Node(name, parent, t, r, label=label)

# ------------------------------------------------------------------ layout (metres)
D, CAB_TOP, TOP = 0.62, 0.84, 0.87
SCAN_LEN, BAG_LEN, BELT_LEN = 0.6, 0.9, 1.8
L = BELT_LEN + SCAN_LEN + BAG_LEN
beltX0 = -L / 2
beltX1 = beltX0 + BELT_LEN
scanCx = beltX1 + SCAN_LEN / 2
bagX0 = beltX1 + SCAN_LEN

root = G('CheckoutStation', None, label='Checkout station')
root.extras.update({'kit': 'grocery-checkout-kit', 'version': '0.1.0', 'units': 'metres',
                    'flow': '+X', 'cashierSide': '+Z', 'customerSide': '-Z'})

# counter
counter = G('Counter', root, label='Counter cabinet')
P(box(L - 0.08, 0.08, D - 0.08), 'Kit_Kick', 'KickPlinth', counter, (0, 0.04, 0))
P(rbox(L, CAB_TOP - 0.08, D, 0.03, S=3), 'Kit_Cabinet', 'Cabinet', counter, (0, 0.08 + (CAB_TOP - 0.08) / 2, 0))
P(rbox(L - 0.06, 0.07, 0.012, 0.005), 'Kit_Accent', 'BrandStripe', counter, (0, 0.74, -D / 2 - 0.004))
P(rbox(L + 0.04, TOP - CAB_TOP, D + 0.05, 0.012), 'Kit_Countertop', 'Countertop', counter, (0, (TOP + CAB_TOP) / 2, 0))
P(box(0.46, 0.13, 0.004), 'Kit_Kick', 'DrawerOpening', counter, (scanCx, 0.73, D / 2 + 0.001))

# belt
belt = G('Belt', root, label='Conveyor belt')
BW = 0.44
bedX0, bedX1 = beltX0 + 0.07, beltX1 - 0.04
bedLen = bedX1 - bedX0
BELT_Y = TOP + 0.012
P(box(bedLen, 0.012, BW), 'Kit_Rubber', 'BeltSurface', belt, ((bedX0 + bedX1) / 2, TOP + 0.006, 0))
for nm, x in (('RollerEntry', bedX0), ('RollerExit', bedX1)):
    P(cyl(0.014, 0.014, BW + 0.01, 20), 'Kit_Steel', nm, belt, (x, TOP + 0.004, 0), (math.pi / 2, 0, 0))
for nm, s in (('RailCustomer', -1), ('RailCashier', 1)):
    P(rbox(BELT_LEN - 0.02, 0.035, 0.03, 0.01), 'Kit_Steel', nm, belt, ((beltX0 + beltX1) / 2, TOP + 0.0175, s * (BW / 2 + 0.017)))
cleats_g = G('BeltCleats', belt)
cleat_count = max(4, int(bedLen // 0.09))
pitch = bedLen / cleat_count
cleats = [P(box(0.012, 0.003, BW - 0.03), 'Kit_Ridge', f'BeltCleat{i:02d}', cleats_g, (bedX0 + i * pitch, BELT_Y + 0.0015, 0))
          for i in range(cleat_count)]
sensor = G('BeltSensor', belt, (bedX1 - 0.12, TOP + 0.035, 0), label='Belt photo-eye')
for s in (-1, 1):
    side = 'Customer' if s < 0 else 'Cashier'
    P(rbox(0.03, 0.04, 0.02, 0.006), 'Kit_DarkPlastic', f'SensorHousing{side}', sensor, (0, 0.02, s * (BW / 2 + 0.017)))
    P(box(0.008, 0.008, 0.002), 'Glow_BeltEye', f'SensorEye{side}', sensor, (0, 0.024, s * (BW / 2 + 0.006)))
P(('prism', (((-0.031, 0), (0.031, 0), (0, 0.046)), BW - 0.06), {}), 'Kit_Accent', 'DividerBar', root,
  (beltX0 + 0.5, BELT_Y + 0.023, 0), label='Next-customer divider')

# scanner
scanner = G('Scanner', root, (scanCx, TOP, 0), label='Bi-optic scanner and scale')
P(rbox(0.46, 0.012, 0.40, 0.006), 'Kit_DarkPlastic', 'ScaleFrame', scanner, (0, 0.006, 0.02))
P(box(0.40, 0.004, 0.34), 'Glow_ScannerGlass', 'ScaleGlass', scanner, (0, 0.0135, 0.02))
towerZ = -0.25  # tower on the customer side, window facing the cashier
P(rbox(0.42, 0.22, 0.09, 0.025, S=3), 'Kit_DarkPlastic', 'ScannerTower', scanner, (0, 0.11, towerZ))
P(box(0.30, 0.13, 0.006), 'Glow_ScannerGlass', 'TowerWindow', scanner, (0, 0.115, towerZ + 0.047))
P(cyl(0.012, 0.012, 0.006, 16), 'Glow_ScannerLED', 'ScannerStatusLED', scanner, (0.16, 0.223, towerZ))

# cash drawer
drawer = G('CashDrawer', root, (scanCx, 0, 0), label='Cash drawer')
DR_Y = 0.73
P(rbox(0.44, 0.11, 0.025, 0.008), 'Kit_DarkPlastic', 'DrawerFront', drawer, (0, DR_Y, D / 2 + 0.0125))
P(box(0.42, 0.09, 0.40), 'Kit_MidPlastic', 'DrawerBody', drawer, (0, DR_Y - 0.005, D / 2 - 0.20))
for i in range(5):
    P(box(0.072, 0.012, 0.12), 'Kit_LightPlastic', f'BillSlot{i}', drawer, (-0.164 + i * 0.082, DR_Y + 0.046, D / 2 - 0.08))
for i in range(4):
    P(cyl(0.028, 0.028, 0.012, 16), 'Kit_Steel', f'CoinCup{i}', drawer, (-0.13 + i * 0.087, DR_Y + 0.046, D / 2 - 0.23))
P(cyl(0.008, 0.008, 0.01, 12), 'Kit_Steel', 'DrawerLock', drawer, (0.17, DR_Y, D / 2 + 0.027), (math.pi / 2, 0, 0))

# POS terminal
pos = G('POSTerminal', root, (beltX1 + 0.02, TOP, 0.285), label='POS terminal')
P(cyl(0.075, 0.075, 0.012), 'Kit_DarkPlastic', 'PoleBase', pos, (0, 0.006, 0))
P(cyl(0.02, 0.02, 0.40, 16), 'Kit_Steel', 'Pole', pos, (0, 0.212, 0))
head = G('POSHead', pos, (0, 0.41, 0), (0, 0.45, 0))
P(rbox(0.06, 0.08, 0.05, 0.01), 'Kit_DarkPlastic', 'MonitorNeck', head, (0, 0.04, 0.02))
monitor = G('POSMonitor', head, (0, 0.17, 0.05), (-0.22, 0, 0), label='POS touchscreen')
P(rbox(0.38, 0.30, 0.05, 0.018, S=3), 'Kit_DarkPlastic', 'MonitorBezel', monitor)
P(box(0.33, 0.245, 0.004), 'Glow_POSScreen', 'MonitorScreen', monitor, (0, 0.01, 0.026))
P(box(0.31, 0.03, 0.002), 'Glow_ScreenUI', 'UIHeader', monitor, (0, 0.105, 0.0285))
for i in range(5):
    P(box(0.18, 0.012, 0.002), 'Glow_ScreenUI', f'UILine{i}', monitor, (-0.055, 0.062 - i * 0.028, 0.0285))
P(box(0.09, 0.07, 0.002), 'Glow_ScreenTotal', 'UITotal', monitor, (0.105, -0.07, 0.0285))
P(box(0.05, 0.008, 0.002), 'Kit_Accent', 'BezelBadge', monitor, (0, -0.137, 0.026))
P(box(0.03, 0.02, 0.12), 'Kit_DarkPlastic', 'KeyboardArm', head, (0, -0.21, 0.07))
kb = G('POSKeyboard', head, (0, -0.20, 0.14), (0.28, 0, 0), label='POS keyboard')
P(rbox(0.34, 0.03, 0.15, 0.01), 'Kit_DarkPlastic', 'KeyboardBody', kb)
for r in range(3):
    for c in range(8):
        m = ('Kit_KeyGreen' if r == 2 else 'Kit_KeyYellow' if r == 1 else 'Kit_KeyRed') if c == 7 else 'Kit_LightPlastic'
        P(box(0.03, 0.012, 0.03), m, f'Key{r}_{c}', kb, (-0.133 + c * 0.038, 0.019, -0.038 + r * 0.038))
cd = G('CustomerDisplay', pos, (0, 0.30, 0), (0, math.pi + 0.2, 0), label='Customer display')
cdp = G('CustomerDisplayPanel', cd, (0, 0, 0.04), (-0.1, 0, 0))
P(rbox(0.24, 0.15, 0.04, 0.012), 'Kit_DarkPlastic', 'CustomerDisplayBezel', cdp)
P(box(0.21, 0.12, 0.004), 'Glow_CustomerScreen', 'CustomerDisplayScreen', cdp, (0, 0, 0.021))
for i in range(3):
    P(box(0.12, 0.01, 0.002), 'Glow_ScreenUI', f'CustUILine{i}', cdp, (-0.035, 0.035 - i * 0.025, 0.0235))
P(box(0.06, 0.04, 0.002), 'Glow_ScreenTotal', 'CustUITotal', cdp, (0.06, -0.035, 0.0235))

# PIN pad
pin = G('PinPad', root, (bagX0 + 0.03, TOP, -0.275), label='Customer PIN pad')
P(cyl(0.05, 0.05, 0.01), 'Kit_DarkPlastic', 'PinPadBase', pin, (0, 0.005, 0))
P(cyl(0.012, 0.012, 0.14, 12), 'Kit_Steel', 'PinPadStem', pin, (0, 0.08, 0))
pad = G('PinPadHead', pin, (0, 0.165, 0), (-0.55, 0, 0))
P(rbox(0.10, 0.03, 0.18, 0.012), 'Kit_DarkPlastic', 'PinPadBody', pad)
P(box(0.08, 0.003, 0.06), 'Glow_PinPadScreen', 'PinPadScreen', pad, (0, 0.016, 0.045))
for r in range(4):
    for c in range(3):
        m = ['Kit_KeyRed', 'Kit_KeyYellow', 'Kit_KeyGreen'][c] if r == 3 else 'Kit_LightPlastic'
        P(box(0.018, 0.006, 0.014), m, f'PinKey{r}_{c}', pad, (-0.026 + c * 0.026, 0.017, -0.012 - r * 0.02))
P(box(0.07, 0.008, 0.012), 'Kit_Kick', 'CardSlot', pad, (0, -0.006, -0.092))

# receipt printer
printer = G('ReceiptPrinter', root, (bagX0 + 0.11, TOP, 0.21), (0, -0.6, 0), label='Receipt printer')
P(rbox(0.15, 0.12, 0.18, 0.025, S=3), 'Kit_MidPlastic', 'PrinterBody', printer, (0, 0.06, 0))
P(box(0.152, 0.004, 0.11), 'Kit_DarkPlastic', 'PrinterLidSeam', printer, (0, 0.119, -0.02))
P(box(0.10, 0.006, 0.012), 'Kit_Kick', 'PaperSlot', printer, (0, 0.121, 0.05))
P(box(0.01, 0.01, 0.002), 'Glow_PrinterLED', 'PrinterLED', printer, (0.05, 0.09, 0.091))
RECEIPT_REST = 0.001
receipt = P(box(0.08, 1.0, 0.0015, offset=(0, 0.5, 0)), 'Kit_Paper', 'Receipt', printer,
            (0, 0.121, 0.05), (0.3, 0, 0), (1, RECEIPT_REST, 1), label='Receipt')

# bag carousel
car = G('BagCarousel', root, (bagX0 + 0.52, TOP, -0.02), label='Bag carousel')
P(cyl(0.2, 0.22, 0.03, 32), 'Kit_DarkPlastic', 'CarouselBase', car, (0, 0.015, 0))
P(cyl(0.018, 0.018, 0.46, 16), 'Kit_Steel', 'CarouselPost', car, (0, 0.26, 0))
spinner = G('BagCarouselSpinner', car)
P(cyl(0.035, 0.035, 0.04, 20), 'Kit_DarkPlastic', 'CarouselHub', spinner, (0, 0.45, 0))
for k in range(3):
    arm = G(f'CarouselArm{k}', spinner, r=(0, k * TAU / 3, 0))
    P(box(0.012, 0.012, 0.17), 'Kit_Steel', f'Spoke{k}', arm, (0, 0.45, 0.085))
    P(box(0.24, 0.012, 0.012), 'Kit_Steel', f'Crossbar{k}', arm, (0, 0.45, 0.17))
    bag = G(f'Bag{k}', arm, (0, 0.20, 0.17), label='Shopping bag')
    bag.extras['innerFloorY'] = -0.166
    P(cyl(0.155, 0.145, 0.34, 4, open_ended=True, flat=True, theta0=math.pi / 4), 'Kit_Bag', f'BagBody{k}', bag)
    P(box(0.205, 0.004, 0.205), 'Kit_Bag', f'BagBottom{k}', bag, (0, -0.168, 0))
    for side, x in (('L', -0.1), ('R', 0.1)):
        P(box(0.003, 0.09, 0.012), 'Kit_Bag', f'BagHandle{side}{k}', bag, (x, 0.21, 0))

# lane light with seven-segment lane number (geometry, no textures)
lane = G('LaneLight', root, (beltX0 + 0.03, TOP, 0.30), label='Lane light')
P(cyl(0.04, 0.045, 0.015), 'Kit_DarkPlastic', 'LaneLightBase', lane, (0, 0.0075, 0))
P(cyl(0.016, 0.016, 1.05, 12), 'Kit_Steel', 'LaneLightPole', lane, (0, 0.54, 0))
sign = P(rbox(0.2, 0.2, 0.2, 0.012), 'Kit_Accent', 'LaneNumberSign', lane, (0, 1.165, 0))
SEGMENTS = {'0': 'abcdef', '1': 'bc', '2': 'abged', '3': 'abgcd', '4': 'fgbc', '5': 'afgcd',
            '6': 'afgedc', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg'}
DW, DH, ST = 0.075, 0.13, 0.017
SEG_GEO = {
    'a': (0, DH / 2, 'h'), 'g': (0, 0, 'h'), 'd': (0, -DH / 2, 'h'),
    'b': (DW / 2, DH / 4, 'v'), 'c': (DW / 2, -DH / 4, 'v'),
    'f': (-DW / 2, DH / 4, 'v'), 'e': (-DW / 2, -DH / 4, 'v'),
}
digits = SEGMENTS[LANE_NUMBER]
for f in range(4):
    face = G(f'LaneNumberFace{f}', sign, r=(0, f * math.pi / 2, 0))
    for sname in digits:
        x, y, o = SEG_GEO[sname]
        g = box(DW - ST, ST, 0.003) if o == 'h' else box(ST, DH / 2 - ST * 0.6, 0.003)
        P(g, 'Glow_LaneNumber', f'Digit{f}_{sname}', face, (x, y, 0.1015))
P(cyl(0.075, 0.085, 0.07, 24), 'Glow_LaneLamp', 'LaneLamp', lane, (0, 1.3, 0))
P(cyl(0.05, 0.075, 0.025, 24), 'Kit_DarkPlastic', 'LaneLampCap', lane, (0, 1.347, 0))

# cashier mat
P(rbox(1.1, 0.014, 0.62, 0.007), 'Kit_FloorMat', 'CashierMat', root, (scanCx - 0.1, 0.007, D / 2 + 0.45), label='Cashier floor mat')

# anchors: empty nodes for choreography
anchors_g = G('Anchors', root)
ANCHORS = {
    'BeltEntry': (bedX0 + 0.12, BELT_Y, 0), 'BeltExit': (bedX1 - 0.05, BELT_Y, 0),
    'BeltSensor': (bedX1 - 0.12, BELT_Y, 0), 'ScanPoint': (scanCx, TOP + 0.016, 0.02),
    'BagCarousel': (bagX0 + 0.52, TOP + 0.03, -0.02), 'PinPad': (bagX0 + 0.03, TOP + 0.18, -0.275),
    'DividerRest': (beltX0 + 0.5, BELT_Y, 0), 'CashierStand': (scanCx - 0.05, 0, D / 2 + 0.45),
    'CustomerStand': (scanCx - 0.1, 0, -D / 2 - 0.55), 'CustomerUnload': (beltX0 + 0.45, 0, -D / 2 - 0.5),
    'QueueStart': (beltX0 - 0.6, 0, -D / 2 - 0.6),
}
for k, v in ANCHORS.items():
    G(f'Anchor_{k}', anchors_g, v)

# ------------------------------------------------------------------ animation clips
def eased(n=8):
    t = np.linspace(0, 1, n)
    return t, np.where(t < 0.5, 2 * t * t, 1 - (-2 * t + 2) ** 2 / 2)

anims = []
speed = 0.18
period = bedLen / speed
belt_run = Animation('BeltRun')  # loops seamlessly
for i, c in enumerate(cleats):
    x0 = bedX0 + i * pitch
    tw = (bedX1 - x0) / speed
    y, z = c.t[1], c.t[2]
    if tw >= period - 1e-6:  # first cleat travels the full bed in one cycle
        times, vals = [0.0, period], [(x0, y, z), (bedX1, y, z)]
    else:
        times = [0.0, tw, tw + 1e-4, period]
        vals = [(x0, y, z), (bedX1, y, z), (bedX0, y, z), (x0, y, z)]
    belt_run.add(c, 'translation', times, vals)
anims.append(belt_run)

t, e = eased()
for name, a, b in (('CashDrawerOpen', 0.0, 0.30), ('CashDrawerClose', 0.30, 0.0)):
    an = Animation(name)
    an.add(drawer, 'translation', t * 0.45, [(scanCx, 0, a + (b - a) * k) for k in e])
    anims.append(an)

an = Animation('BagCarouselTurn')  # one bag (120°); the rig is symmetric so it can be replayed
an.add(spinner, 'rotation', t * 0.6, [euler_xyz_to_quat(0, k * TAU / 3, 0) for k in e])
anims.append(an)

an = Animation('ReceiptPrint')
tt = np.linspace(0, 1.6, 9)
an.add(receipt, 'scale', tt, [(1, RECEIPT_REST + (0.22 - RECEIPT_REST) * k, 1) for k in tt / 1.6])
anims.append(an)

an = Animation('ReceiptTear')
an.add(receipt, 'scale', [0, 0.05], [(1, 0.22, 1), (1, RECEIPT_REST, 1)])
anims.append(an)

# ------------------------------------------------------------------ export
os.makedirs(os.path.join(OUT, 'components'), exist_ok=True)
report = {}
report['checkout-station.glb'] = write_glb(os.path.join(OUT, 'checkout-station.glb'), [root], MAT, anims)

def standalone(node):
    """Copy a component and move it to the origin (mounting base at 0,0,0, no yaw)."""
    n = copy.deepcopy(node)
    n.t, n.r = [0, 0, 0], [0, 0, 0]
    return n

COMPONENTS = {
    'scanner-scale.glb': ('Scanner', []),
    'pos-terminal.glb': ('POSTerminal', []),
    'pin-pad.glb': ('PinPad', []),
    'receipt-printer.glb': ('ReceiptPrinter', ['ReceiptPrint', 'ReceiptTear']),
    'bag-carousel.glb': ('BagCarousel', ['BagCarouselTurn']),
    'lane-light.glb': ('LaneLight', []),
    'divider-bar.glb': ('DividerBar', []),
}
for fname, (node_name, clip_names) in COMPONENTS.items():
    src = root.find(node_name)
    comp = standalone(src)
    if node_name == 'DividerBar':
        comp.t = [0, 0.023, 0]  # sits on the floor plane
    comp_anims = []
    for a in anims:
        if a.name not in clip_names:
            continue
        ca = Animation(a.name)
        for node, path, times, vals in a.channels:
            target = comp.find(node.name)
            if target is not None:
                ca.add(target, path, times, vals)
        comp_anims.append(ca)
    report['components/' + fname] = write_glb(os.path.join(OUT, 'components', fname), [comp], MAT, comp_anims)

json.dump({'report': report, 'root': root.name}, open(os.path.join(OUT, '_report.json'), 'w'), indent=1)
for k, v in report.items():
    print(f"{k:34s} {v['bytes']/1024:7.1f} KB  tris {v['triangles']:6d}  nodes {v['nodes']:4d}  anims {v['animations']}")

# Pickle the scene for the preview renderer.
import pickle
pickle.dump((root, MAT), open(os.path.join(OUT, '_scene.pkl'), 'wb'))
