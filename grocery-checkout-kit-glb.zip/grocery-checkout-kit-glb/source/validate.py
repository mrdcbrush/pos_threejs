import json, struct, sys, glob
import numpy as np
CT = {5126: ('f4', 4), 5123: ('u2', 2), 5125: ('u4', 4)}
NC = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}
def check(path):
    b = open(path, 'rb').read()
    magic, ver, total = struct.unpack_from('<III', b, 0)
    assert magic == 0x46546C67 and ver == 2 and total == len(b), 'header'
    jl, jt = struct.unpack_from('<II', b, 12); assert jt == 0x4E4F534A and jl % 4 == 0
    doc = json.loads(b[20:20 + jl])
    bl, bt = struct.unpack_from('<II', b, 20 + jl); assert bt == 0x004E4942 and bl % 4 == 0
    bin_ = b[28 + jl:28 + jl + bl]; assert len(bin_) == doc['buffers'][0]['byteLength']
    def read(ai):
        a = doc['accessors'][ai]; v = doc['bufferViews'][a['bufferView']]
        dt, sz = CT[a['componentType']]; n = NC[a['type']]
        assert v['byteOffset'] % 4 == 0 and v['byteOffset'] + v['byteLength'] <= len(bin_)
        assert a['count'] * n * sz <= v['byteLength']
        return np.frombuffer(bin_, dt, a['count'] * n, v['byteOffset']).reshape(a['count'], n)
    for m in doc['meshes']:
        for p in m['primitives']:
            pos = read(p['attributes']['POSITION']); nrm = read(p['attributes']['NORMAL']); idx = read(p['indices'])
            assert len(pos) == len(nrm) and idx.max() < len(pos) and len(idx) % 3 == 0
            assert np.allclose(np.linalg.norm(nrm, axis=1), 1, atol=1e-3), 'normals'
            a = doc['accessors'][p['attributes']['POSITION']]
            assert np.allclose(a['min'], pos.min(0)) and np.allclose(a['max'], pos.max(0))
            assert p['material'] < len(doc['materials'])
    for an in doc.get('animations', []):
        for c in an['channels']:
            s = an['samplers'][c['sampler']]; t = read(s['input']).ravel(); o = read(s['output'])
            assert np.all(np.diff(t) > 0), f"times not increasing in {an['name']}"
            assert len(o) == len(t) and c['target']['node'] < len(doc['nodes'])
    names = [n['name'] for n in doc['nodes']]
    assert len(names) == len(set(names)), 'duplicate node names: ' + str([x for x in names if names.count(x) > 1][:5])
    for n in doc['nodes']:
        for c in n.get('children', []): assert c < len(doc['nodes'])
        if 'rotation' in n: assert abs(np.linalg.norm(n['rotation']) - 1) < 1e-5
    return doc
for f in sorted(glob.glob(sys.argv[1] + '/**/*.glb', recursive=True)):
    d = check(f); print('valid', f, len(d['nodes']), 'nodes', len(d['materials']), 'materials')
