# Grocery checkout kit: GLB assets (v0.1.0)

Binary glTF 2.0 files with no textures. Each part has a plain colour and a surface finish (roughness, metalness and glow).

## Conventions

These apply to every asset in the kit:

- **Scale and axes:** 1 unit = 1 metre, and +Y is up.
- **Origin:** on the floor, at the centre of the footprint.
- **Station orientation:** groceries flow toward +X. The cashier works from the +Z side and the customer stands on the −Z side.
- **Component origins:** files in `components/` have their origin at their mounting base, so they drop onto a counter at y = 0.87.
- **Colour:** colours are stored in linear space, so they render as intended in three.js with sRGB output.
- **Shared materials:** every file uses the same `Kit_*` material names, so assets combined in one scene share a single palette.
- **Glowing parts:** `Glow_*` materials are emissive, one per part, so screens, lamps and the scanner window can be animated independently. Glow above 1.0 uses `KHR_materials_emissive_strength`; three.js r137+ reads it and older loaders fall back to 1.0.

## Files

| File | Contents | Size |
| --- | --- | --- |
| `checkout-station.glb` | Full lane, 9.4k triangles, 6 animation clips | 3.39 × 2.23 × 1.43 m |
| `components/scanner-scale.glb` | Bi-optic scanner and scale | 0.46 × 0.23 × 0.52 m |
| `components/pos-terminal.glb` | Pole, touchscreen, keyboard, customer display | 0.41 × 0.73 × 0.35 m |
| `components/pin-pad.glb` | Customer PIN pad on stem | 0.10 × 0.22 × 0.16 m |
| `components/receipt-printer.glb` | Printer with `ReceiptPrint` and `ReceiptTear` clips | 0.15 × 0.12 × 0.18 m |
| `components/bag-carousel.glb` | Three-bag carousel with `BagCarouselTurn` clip | 0.59 × 0.49 × 0.51 m |
| `components/lane-light.glb` | Pole, lane number "4" sign, lamp | 0.21 × 1.36 × 0.21 m |
| `components/divider-bar.glb` | Next-customer divider | 0.06 × 0.05 × 0.38 m |

The lane number is built from seven-segment geometry rather than a texture. Change `LANE_NUMBER` in `source/build_station.py` to produce other lanes.

## Animation clips (checkout-station.glb)

| Clip | Length | What moves |
| --- | --- | --- |
| `BeltRun` | 9.39 s, loops seamlessly | Belt cleats travel at 0.18 m/s |
| `CashDrawerOpen` / `CashDrawerClose` | 0.45 s | `CashDrawer` slides 0.30 m toward the cashier |
| `BagCarouselTurn` | 0.6 s | `BagCarouselSpinner` turns one bag (120°); replay for each turn |
| `ReceiptPrint` / `ReceiptTear` | 1.6 s / 0.05 s | `Receipt` scales from hidden to 0.22 m long |

Effects driven by material colour, such as the scanner flash, screen colours and lane-light blink, are left for code. Target these materials by name:

- `Glow_ScannerGlass`
- `Glow_ScannerLED`
- `Glow_POSScreen`
- `Glow_CustomerScreen`
- `Glow_PinPadScreen`
- `Glow_LaneLamp`
- `Glow_ScreenUI`
- `Glow_ScreenTotal`

## Named nodes worth targeting

Nodes carrying a readable `extras.label` (three.js puts this in `userData.label`):

`CheckoutStation`, `Counter`, `Belt`, `BeltSensor`, `DividerBar`, `Scanner`, `CashDrawer`, `POSTerminal`, `POSMonitor`, `POSKeyboard`, `CustomerDisplay`, `PinPad`, `ReceiptPrinter`, `Receipt`, `BagCarousel`, `Bag0`, `Bag1`, `Bag2`, `LaneLight`, `CashierMat`.

Each `Bag*` node also carries `extras.innerFloorY` (−0.166), the local height of the bag floor, for dropping items into it.

## Anchors

Empty nodes under `Anchors` mark positions for choreographing items and people:

- `Anchor_BeltEntry`
- `Anchor_BeltExit`
- `Anchor_BeltSensor`
- `Anchor_ScanPoint`
- `Anchor_BagCarousel`
- `Anchor_PinPad`
- `Anchor_DividerRest`
- `Anchor_CashierStand`
- `Anchor_CustomerStand`
- `Anchor_CustomerUnload`
- `Anchor_QueueStart`

The belt surface is at y = 0.882.

## Rebuilding

The `source/` scripts regenerate every file with Python 3 and NumPy only:

```
python3 build_station.py out
python3 validate.py out
```

`validate.py` checks headers, buffer bounds, index ranges, normals, keyframe order and unique node names.
