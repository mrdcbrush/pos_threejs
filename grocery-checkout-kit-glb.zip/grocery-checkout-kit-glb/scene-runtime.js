/**
 * Grocery checkout kit: scene runtime.
 * Reads a scene file (scene.json), loads the GLB assets, places objects and plays the timeline.
 *
 *   import * as THREE from 'three';
 *   import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
 *   import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';   // optional
 *   import { createCheckoutScene } from './scene-runtime.js';
 *   const manifest = await (await fetch('scene.json')).json();
 *   const app = await createCheckoutScene({ THREE, GLTFLoader, OrbitControls, container, manifest, assetBase: './' });
 */
export async function createCheckoutScene({ THREE, GLTFLoader, OrbitControls, container, manifest, assetBase = '' }) {
  // ------------------------------------------------------------ renderer, camera, lights
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  if ('outputColorSpace' in renderer && THREE.SRGBColorSpace) renderer.outputColorSpace = THREE.SRGBColorSpace;
  else renderer.outputEncoding = THREE.sRGBEncoding;
  container.appendChild(renderer.domElement);

  const env = Object.assign({ background: '#e4e7e3', floor: '#d9dcd7', grid: true }, manifest.environment);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(env.background);

  const cam = Object.assign({ position: [-2.7, 2.1, -3.1], target: [0.15, 0.85, 0], fov: 38 }, manifest.camera);
  const camera = new THREE.PerspectiveCamera(cam.fov, 1, 0.05, 60);
  camera.position.fromArray(cam.position);
  const camTarget = new THREE.Vector3().fromArray(cam.target);
  camera.lookAt(camTarget);
  const controls = OrbitControls ? new OrbitControls(camera, renderer.domElement) : null;
  if (controls) { controls.target.copy(camTarget); controls.enableDamping = true; controls.maxPolarAngle = Math.PI * 0.495; }

  scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8f99, 0.9));
  const sun = new THREE.DirectionalLight(0xffffff, 1.6);
  sun.position.set(2.2, 4.6, 3.0);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -4, right: 4, top: 4, bottom: -4, near: 0.5, far: 14 });
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.02;
  scene.add(sun);
  const fill = new THREE.DirectionalLight(0xffffff, 0.4);
  fill.position.set(-3, 2.5, -2.5);
  scene.add(fill);

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ color: env.floor, roughness: 0.95 }));
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  if (env.grid) {
    const grid = new THREE.GridHelper(16, 32, 0xc3c8c1, 0xc3c8c1); // 0.5 m floor tiles
    grid.position.y = 0.001;
    scene.add(grid);
  }

  // ------------------------------------------------------------ assets
  const loader = new GLTFLoader();
  const loadGLB = (url) => new Promise((res, rej) => loader.load(url, res, undefined, rej));
  const assetUrl = (u) => (/^(data:|blob:|https?:|\/)/.test(u) ? u : assetBase + u);
  const assets = {};
  await Promise.all(Object.entries(manifest.assets || {}).map(async ([key, url]) => {
    assets[key] = await loadGLB(assetUrl(url));
  }));

  // ------------------------------------------------------------ objects
  const objects = {};
  const tmp = new THREE.Vector3();

  function resolvePoint(ref, out = new THREE.Vector3()) {
    if (Array.isArray(ref)) return out.fromArray(ref);
    const [id, nodeName] = String(ref).split('/');
    const o = objects[id];
    if (!o) throw new Error(`Scene: unknown object "${id}" in "${ref}"`);
    const node = nodeName ? o.root.getObjectByName(nodeName) : o.root;
    if (!node) throw new Error(`Scene: node "${nodeName}" not found in "${id}"`);
    scene.updateMatrixWorld(true);
    return node.getWorldPosition(out);
  }
  function resolveNode(ref) {
    const [id, nodeName] = String(ref).split('/');
    const o = objects[id];
    return o && (nodeName ? o.root.getObjectByName(nodeName) : o.root);
  }

  function makePrimitive(spec) {
    const color = spec.color || '#c96f4a';
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.6 });
    let geo, h;
    if (spec.box) { geo = new THREE.BoxGeometry(...spec.box); h = spec.box[1]; }
    else if (spec.cylinder) { const [r, hh] = spec.cylinder; geo = new THREE.CylinderGeometry(r, r, hh, 24); h = hh; }
    else throw new Error('Scene: primitive needs "box": [w,h,d] or "cylinder": [radius,height]');
    geo.translate(0, h / 2, 0); // origin at the base, like kit assets
    const g = new THREE.Group();
    g.add(new THREE.Mesh(geo, mat));
    return { root: g, clips: [] };
  }

  for (const def of manifest.objects || []) {
    let root, clips;
    if (def.asset) {
      const gltf = assets[def.asset];
      if (!gltf) throw new Error(`Scene: asset "${def.asset}" is not listed in "assets"`);
      root = gltf.scene.clone(true);
      clips = gltf.animations || [];
    } else if (def.primitive) {
      ({ root, clips } = makePrimitive(def.primitive));
    } else {
      throw new Error(`Scene: object "${def.id}" needs "asset" or "primitive"`);
    }
    root.name = def.id;
    // Each object gets its own copies of glowing materials so lanes animate independently.
    const glow = {};
    root.traverse((n) => {
      if (!n.isMesh) return;
      n.castShadow = n.receiveShadow = true;
      if (n.material && /^Glow_/.test(n.material.name)) {
        const name = n.material.name;
        if (!glow[name]) { glow[name] = n.material.clone(); glow[name].userData.base = glow[name].emissiveIntensity; }
        n.material = glow[name];
      }
    });
    scene.add(root);
    if (def.at) resolvePoint(def.at, root.position); else root.position.fromArray(def.position || [0, 0, 0]);
    if (def.offset) root.position.add(tmp.fromArray(def.offset));
    root.rotation.y = def.rotationY || 0;
    if (def.scale) root.scale.setScalar(def.scale);
    if (def.visible === false) root.visible = false;
    const mixer = new THREE.AnimationMixer(root);
    objects[def.id] = {
      id: def.id, root, clips, mixer, glow, glowFx: {},
      home: { position: root.position.clone(), quaternion: root.quaternion.clone(), visible: root.visible },
    };
  }

  // ------------------------------------------------------------ timeline
  const events = (manifest.timeline || []).slice().sort((a, b) => a.t - b.t);
  const loopAt = manifest.loop ? Number(manifest.loop) : 0;
  const moves = [];
  let camMove = null;
  let clock = 0;
  let cursor = 0;

  function getObj(id) {
    const o = objects[id];
    if (!o) throw new Error(`Scene: unknown object "${id}"`);
    return o;
  }

  function fire(e) {
    if (e.play) {
      const o = getObj(e.target);
      const clip = THREE.AnimationClip.findByName(o.clips, e.play);
      if (!clip) { console.warn(`Scene: clip "${e.play}" not found on "${e.target}"`); return; }
      const nodesOf = (c) => new Set(c.tracks.map((tr) => tr.name.split('.')[0]));
      const mine = nodesOf(clip);
      for (const other of o.clips) {
        if (other === clip) continue;
        if ([...nodesOf(other)].some((n) => mine.has(n))) o.mixer.clipAction(other).stop();
      }
      const a = o.mixer.clipAction(clip);
      a.reset();
      a.setLoop(e.loop ? THREE.LoopRepeat : THREE.LoopOnce, Infinity);
      a.clampWhenFinished = !e.loop;
      a.timeScale = e.speed || 1;
      a.play();
    }
    if (e.stop) {
      const o = getObj(e.target);
      const clip = THREE.AnimationClip.findByName(o.clips, e.stop);
      if (clip) o.mixer.clipAction(clip).stop();
    }
    if (e.move) {
      const o = getObj(e.move);
      const from = new THREE.Vector3();
      o.root.getWorldPosition(from);
      const to = resolvePoint(e.to).add(tmp.fromArray(e.offset || [0, 0, 0]));
      const dur = e.duration || (e.speed ? from.distanceTo(to) / e.speed : 0.6);
      if (o.root.parent !== scene) scene.attach(o.root);
      moves.push({ o, from, to: to.clone(), dur: Math.max(dur, 0.001), k: 0, arc: e.arc || 0, attach: e.attach ? e.to : null });
    }
    if (e.glow) {
      const o = getObj(e.target);
      const m = o.glow[e.glow];
      if (!m) { console.warn(`Scene: material "${e.glow}" not found on "${e.target}"`); return; }
      if (e.color) m.emissive.set(e.color);
      o.glowFx[e.glow] = { m, t: 0, dur: e.duration || 0.3, from: m.emissiveIntensity,
        to: e.intensity !== undefined ? e.intensity : m.emissiveIntensity, pulse: e.pulse, blink: e.blink };
    }
    if (e.show || e.hide) getObj(e.show || e.hide).root.visible = !!e.show;
    if (e.camera) {
      camMove = { p0: camera.position.clone(), t0: (controls ? controls.target : camTarget).clone(),
        p1: new THREE.Vector3().fromArray(e.camera.position), t1: new THREE.Vector3().fromArray(e.camera.target),
        dur: e.camera.duration || 1, k: 0 };
    }
  }

  function resetAll() {
    moves.length = 0;
    for (const o of Object.values(objects)) {
      o.mixer.stopAllAction();
      if (o.root.parent !== scene) scene.attach(o.root);
      o.root.position.copy(o.home.position);
      o.root.quaternion.copy(o.home.quaternion);
      o.root.visible = o.home.visible;
      for (const m of Object.values(o.glow)) m.emissiveIntensity = m.userData.base;
      o.glowFx = {};
    }
    clock = 0;
    cursor = 0;
  }

  const ease = (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);

  function step(dt) {
    clock += dt;
    while (cursor < events.length && events[cursor].t <= clock) fire(events[cursor++]);

    for (let i = moves.length - 1; i >= 0; i--) {
      const mv = moves[i];
      mv.k = Math.min(1, mv.k + dt / mv.dur);
      mv.o.root.position.lerpVectors(mv.from, mv.to, mv.arc ? ease(mv.k) : mv.k);
      mv.o.root.position.y += Math.sin(Math.PI * mv.k) * mv.arc;
      if (mv.k >= 1) {
        if (mv.attach) { const node = resolveNode(mv.attach); if (node) node.attach(mv.o.root); }
        moves.splice(i, 1);
      }
    }

    for (const o of Object.values(objects)) {
      o.mixer.update(dt);
      for (const [name, fx] of Object.entries(o.glowFx)) {
        fx.t += dt;
        const k = Math.min(1, fx.t / fx.dur);
        if (fx.pulse !== undefined) fx.m.emissiveIntensity = fx.from + (fx.pulse - fx.from) * Math.sin(Math.PI * k);
        else if (fx.blink) fx.m.emissiveIntensity = Math.sin(fx.t * fx.blink * Math.PI * 2) > 0 ? fx.to : 0.05;
        else fx.m.emissiveIntensity = fx.from + (fx.to - fx.from) * k;
        if (k >= 1 && !fx.blink) { if (fx.pulse !== undefined) fx.m.emissiveIntensity = fx.from; delete o.glowFx[name]; }
      }
    }

    if (camMove) {
      camMove.k = Math.min(1, camMove.k + dt / camMove.dur);
      const e = ease(camMove.k);
      camera.position.lerpVectors(camMove.p0, camMove.p1, e);
      (controls ? controls.target : camTarget).lerpVectors(camMove.t0, camMove.t1, e);
      if (!controls) camera.lookAt(camTarget);
      if (camMove.k >= 1) camMove = null;
    }

    if (loopAt && clock >= loopAt) resetAll();
  }

  // ------------------------------------------------------------ loop and resize
  function resize() {
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  window.addEventListener('resize', resize);

  let last = performance.now();
  let running = true;
  function frame(now) {
    if (!running) return;
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;
    step(dt);
    if (controls) controls.update();
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  return {
    scene, camera, renderer, objects,
    fire,                       // trigger any timeline event now, e.g. app.fire({ target: 'lane4', play: 'CashDrawerOpen' })
    restart: resetAll,
    stop() { running = false; renderer.dispose(); },
  };
}
