# Building the checkout scene

Three parts work together:

| File | Role |
| --- | --- |
| `checkout-station.glb` (and `components/*.glb`) | The 3D models, with built-in animation clips, glowing materials and anchor points |
| `scene.json` | What to load, where to put it, and what happens when |
| `scene-runtime.js` | Three.js code that reads `scene.json`, loads the GLBs, places objects and plays the timeline |

## Page setup

```html
<div id="scene" style="width:100%;height:100vh"></div>
<script type="module">
  import * as THREE from 'three';
  import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
  import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
  import { createCheckoutScene } from './scene-runtime.js';

  const manifest = await (await fetch('scene.json')).json();
  createCheckoutScene({
    THREE, GLTFLoader, OrbitControls,
    container: document.getElementById('scene'),
    manifest,
    assetBase: './',          // folder holding the .glb files
  });
</script>
```

If the GLB files can't be hosted next to the page, replace each path in `scene.json` → `assets` with a `data:model/gltf-binary;base64,...` URI. The runtime accepts either form. The scene file can also be inlined as a JS object instead of fetched.

## Coordinate rules

- **Units:** 1 unit = 1 metre, and +Y is up.
- **Origins:** every asset's origin is on the floor at the centre of its footprint.
- **Station orientation:** groceries flow toward +X. The cashier side is +Z and the customer side is −Z.

## scene.json

`assets` maps a short key to a GLB file.

`objects` places things in the scene. List them in order, because an object can only reference objects listed before it.

- `asset`: key from `assets`. Alternatively use `primitive` for a stand-in shape, such as `{ "box": [w,h,d], "color": "#hex" }` or `{ "cylinder": [radius, height] }`. Primitives have their origin at the base.
- `position: [x,y,z]`: an exact position. Alternatively use `at: "objectId/NodeName"` to snap to a node in another object, for example `"lane4/Anchor_BeltEntry"`.
- `offset: [x,y,z]`, `rotationY` (radians), `scale`, `visible`: optional adjustments.

`timeline` is a list of events, each with a start time `t` in seconds. `loop: 15` resets everything and replays every 15 seconds.

| Event | Fields | Effect |
| --- | --- | --- |
| Play clip | `target`, `play`, optional `loop`, `speed` | Plays a clip built into the GLB |
| Stop clip | `target`, `stop` | Stops a clip and returns its parts to rest |
| Move | `move`, `to`, optional `offset`, `duration` or `speed`, `arc`, `attach` | Moves an object to a point. `arc` lifts it along the way. `attach: true` parents it to the target node, so an item dropped into a bag turns with the carousel |
| Glow | `target`, `glow`, plus `pulse` (peak, then back), `intensity` (fade to) or `blink` (flashes per second), with optional `duration`, `color` | Animates a glowing material |
| Show or hide | `show` or `hide` | Toggles visibility |
| Camera | `camera: { position, target, duration }` | Moves the camera smoothly |

`to` takes either `[x,y,z]` or `"objectId/NodeName"`. Each object gets its own copies of the glowing materials, so two lanes can flash independently.

## Names available in checkout-station.glb

**Animation clips:**

- `BeltRun`: loops, belt cleats move at 0.18 m/s.
- `CashDrawerOpen` and `CashDrawerClose`.
- `BagCarouselTurn`: turns one bag. Replay it for each turn.
- `ReceiptPrint` and `ReceiptTear`.

**Glowing materials**, at resting intensity 1. Pulse the scanner to about 10 and screens to about 2:

- `Glow_ScannerGlass`, `Glow_ScannerLED`
- `Glow_POSScreen`, `Glow_CustomerScreen`, `Glow_PinPadScreen`
- `Glow_ScreenUI`, `Glow_ScreenTotal`
- `Glow_LaneLamp`, `Glow_LaneNumber`
- `Glow_BeltEye`, `Glow_PrinterLED`

**Anchors:**

- `Anchor_BeltEntry`, `Anchor_BeltExit`, `Anchor_BeltSensor`
- `Anchor_ScanPoint`, `Anchor_BagCarousel`, `Anchor_PinPad`, `Anchor_DividerRest`
- `Anchor_CashierStand`, `Anchor_CustomerStand`, `Anchor_CustomerUnload`, `Anchor_QueueStart`

**Bags:** `Bag0`, `Bag1` and `Bag2` (`Bag0` faces the cashier at rest). To drop an item onto a bag's floor, use `offset: [x, -0.166, z]` with `attach: true`.

**Parts:** `Scanner`, `CashDrawer`, `POSTerminal`, `POSMonitor`, `PinPad`, `ReceiptPrinter`, `Receipt`, `BagCarousel`, `BagCarouselSpinner`, `LaneLight`, `DividerBar`.

## The included scene

`scene.json` runs one 15-second checkout on lane 4:

1. Three stand-in items ride the belt.
2. Each item is lifted over the scanner, which flashes along with the POS screen, then dropped into the front bag.
3. The total shows, the drawer opens and a receipt prints.
4. The drawer closes, the receipt tears off and the carousel turns.

When real grocery GLBs exist, add them to `assets` and swap each `primitive` for `asset`. The timeline stays the same.

## Extending

- **More lanes:** add another station object with a different `position`. Lanes 1.6 m apart side by side, along Z, work well. Give it a new `id`, then reference it in events as `"lane5/Anchor_ScanPoint"` and so on.
- **Driving from live data:** the runtime returns `app.fire(event)`, which triggers any event immediately. For example, `app.fire({ target: 'lane4', glow: 'Glow_LaneLamp', blink: 2, duration: 5 })` flashes the lane light when a queue metric crosses a threshold.
